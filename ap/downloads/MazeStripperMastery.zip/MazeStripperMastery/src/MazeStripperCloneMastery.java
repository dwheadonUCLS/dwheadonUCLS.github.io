import karelthecarpeter.*;
import static karelthecarpeter.Direction.*;

class MazeStripperCloneMastery extends GPSCarpeter {
    
    public MazeStripperCloneMastery(World w, int latitude, int longitude, Direction direction, javafx.scene.paint.Color c) {
        super(w, latitude, longitude, direction, 0, c);
    }

    public boolean leftIsClear() {
        turnLeft();
        if (frontIsClear()) {
            turnRight();
            return true;
        } else {
            turnRight();
            return false;
        }
    }
    
    public boolean rightIsClear() {
        turnRight();
        if (frontIsClear()) {
            turnLeft();
            return true;
        } else {
            turnLeft();
            return false;
        }
    }

    
    private void checkSides() {
        if (leftIsClear()) {
            MazeStripperCloneMastery leftSweeper = new MazeStripperCloneMastery(getWorld(), getLatitude(), getLongitude(), getDirection(), new javafx.scene.paint.Color(Math.random(), Math.random(), Math.random(), 1.0));
            leftSweeper.turnLeft();
            leftSweeper.clearMaze();
        }
        if (rightIsClear()) {
            MazeStripperCloneMastery rightSweeper = new MazeStripperCloneMastery(getWorld(), getLatitude(), getLongitude(), getDirection(), new javafx.scene.paint.Color(Math.random(), Math.random(), Math.random(), 1.0));
            rightSweeper.turnRight();
            rightSweeper.clearMaze();
        }
    }
    
    private void stripRugs() {
        while (onRug()) {
            pickupRug();
        }
    }
    
    public void clearMaze() {
        while (frontIsClear()) {
            stripRugs();
            checkSides();
            move();
        }
        // Once we get to the end, we have to check one last time
        stripRugs();
        checkSides();
    }
}
