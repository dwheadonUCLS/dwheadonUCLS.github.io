import karelthecarpeter.*;
import static karelthecarpeter.Direction.*;

class MazeStripperSolo extends GPSCarpeter {

    public MazeStripperSolo(World w, int latitude, int longitude, Direction direction) {
        super(w, latitude, longitude, direction, 0);
    }
        
    /* 
     * Precondition: Must start at the beginning (inside) of a maze branch
     * Postcondition: Must return to the original position but facing (back) 
     *     in the opposite direction
     * If any side branches are encountered, will himself go into the branch
     *     and clear it and then come back out and carry on
     */
    public void clearMaze() {
        // Note: we assume the back is already clear
    }
}
