import karelthecarpeter.*;
import static karelthecarpeter.Direction.*;
import java.io.*;

class MazeStripperSoloProgram {
    public static void main(String[] args) {
        File worldFile = new File("Maze.kwld");
        World w = new World(worldFile);
        MazeStripperSolo karel = new MazeStripperSolo(w, 1, 10, NORTH);
        karel.clearMaze();
    }
}
