import karelthecarpeter.*;
import static karelthecarpeter.Direction.*;

class MazeStripperClone extends GPSCarpeter {
    private World w;

    public MazeStripperClone(World w, int latitude, int longitude, Direction direction) {
        super(w, latitude, longitude, direction, 0);
        this.w = w; // need to remember this so we can make clones in the same World
    }
        
    /* 
     * Precondition: Must start at the beginning (inside) of a maze branch
     * Postcondition: Will end up at the end of branch in which it was started
     * Should create other clones to clear any side branches it encounters
     */
    public void clearMaze() {
        // Note: we assume the back is already clear
    }
}
