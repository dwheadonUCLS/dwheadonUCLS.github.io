import karelthecarpeter.*;
import static karelthecarpeter.Direction.*;
import java.io.*;

class MazeStripperCloneProgram {
    public static void main(String[] args) {
        File worldFile = new File("Maze.kwld");
        World w = new World(worldFile);
        MazeStripperClone karel = new MazeStripperClone(w, 1, 10, NORTH);
        karel.clearMaze();
    }
}
